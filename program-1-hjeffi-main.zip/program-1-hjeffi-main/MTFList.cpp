// MTF Linked List implementation
// Created by Hannah Jeffi Leo Paul -Student No:2279688 [10/19/2022]
#include <iostream>
#include "LinkedList.h"
#include "MTFList.h"

using namespace std;

/** Constructor for MTFList
    @post Initialize the values of traverseCount to 0 and head Node to nullptr. */
MTFList :: MTFList()
{
    traverseCount = 0;
    head = nullptr;
}

/** Destructor for MTFList
    @post Deletes the Linked List by calling clear() method for clearing memory. */
MTFList :: ~MTFList()
{
    clear();
}

/** Tests whether this list contains a given entry.
    @param anEntry  The entry to locate.
    @post traverseCount is incremented by 1 each time it traverses a node
    @return  True if list contains anEntry, or false otherwise. */
bool MTFList :: contains(int anEntry)
{
    Node *currentNode = head;
    Node *prevNode = nullptr;
    while (currentNode != NULL)
    {
        if (currentNode->data == anEntry)
        {
            if (moveToFront(prevNode, anEntry))
            {
                return true;
            }
            else
                return false;
        }
        prevNode = currentNode;
        currentNode = currentNode->next;
        traverseCount++;
    }
    return false;
}

/** Move the given entry to the front of the List.
    @param anEntry The entry to move
    @return  True if the entry has moved, or false otherwise. */
bool MTFList :: moveToFront(Node *prevNode, int anEntry)
{
    Node *currentNode = nullptr;
    if (head->next == NULL || prevNode == NULL)
    {
        return true;
    }
    currentNode = prevNode->next;
    // Removing the Link
    prevNode->next = currentNode->next;
    // Adding the node to front
    currentNode->next = head;
    head = currentNode;
    return true;
}
