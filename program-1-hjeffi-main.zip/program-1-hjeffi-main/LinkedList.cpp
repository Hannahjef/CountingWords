// Linked List implementation
// Created by Hannah Jeffi Leo Paul -Student No:2279688 [10/19/2022]
#include <iostream>
#include "LinkedList.h"
#include "IList.h"
using namespace std;

/** Constructor for Node
Initializes the data to 0 and next to nullptr. */
Node :: Node()
{
   data = 0;
   next = nullptr;
}

/** Parameterized Constructor for the node
   @post Sets the value of the data to newEntry and next to nullptr
   @param newEntry The entry to be added in the new node. */
Node :: Node(int newEntry)
{
   data = newEntry;
   next = nullptr;
}

/** Constructor for LinkedList
   @post Initialize the values of traverseCount to 0 and head Node to nullptr. */
LinkedList :: LinkedList()
{
   traverseCount = 0;
   head = nullptr;
}
/** Destructor for LinkedList
   @post Deletes the Linked List by calling clear() method for clearing memory. */
LinkedList :: ~LinkedList()
{
   clear();
}
/** Gets the current number of entries in this list.
   @return The integer number of entries currently in the list. */
int LinkedList :: getCurrentSize()
{
   if (head == NULL)
   {
      return 0;
   }
   else
   {
      int listSize = 0;
      Node *tempNode = head;
      while (tempNode != NULL)
      {
         listSize++;
         tempNode = tempNode->next;
      }
      return listSize;
   }
}

/** Sees whether this list is empty.
   @return True if the list is empty, or false if not. */
bool LinkedList :: isEmpty()
{
   if (head == NULL)
   {
      return true;
   }
   return false;
}

/** Adds a new entry to this list.
    @post  If successful, newEntry is stored in the list and
      the count of items in the list has increased by 1.
    @param newEntry  The object to be added as a new entry.
    @return  True if addition was successful, or false if not. */
bool LinkedList :: add(int newEntry)
{
   // int count = getCurrentSize();
   Node *tempNode = head;
   Node *newNode = new Node(newEntry);
   if (isEmpty())
   {
      head = newNode;
   }
   else
   {
      while (tempNode->next != NULL)
      {
         tempNode = tempNode->next;
      }
      tempNode->next = newNode;
   }
   return true;
}

/** Removes one occurrence of a given entry from this list,
       if possible.
    @post  If successful, anEntry has been removed from the list
       and the count of items in the list has decreased by 1.
    @param anEntry  The entry to be removed.
    @return  True if removal was successful, or false if not. */
bool LinkedList :: remove(int anEntry)
{
   Node *tempNode = head;
   Node *prev = nullptr;
   if (tempNode->data == anEntry)
   {
      head->next = tempNode->next;
      delete tempNode;
   }
   else
   {
      while (tempNode != NULL && tempNode->data != anEntry)
      {
         prev = tempNode;
         tempNode = tempNode->next;
      }
      if (tempNode == NULL)
      {
         return false;
      }
      prev->next = tempNode->next;
      delete tempNode;
   }
   return true;
}

/** Removes all entries from this list.
    @post  List contains no items, and the count of items is 0. */
void LinkedList :: clear()
{
   Node *currentNode = head;
   while (currentNode != nullptr)
   {
      head = currentNode->next;
      delete currentNode;
      currentNode = head;
   }
   // delete head;
   head = nullptr;
}

/** Tests whether this list contains a given entry.
   @param anEntry  The entry to locate.
   @return  True if list contains anEntry, or false otherwise.
   @post traverseCount is incremented by 1 each time it traverses a node */
bool LinkedList :: contains(int anEntry)
{
   Node *currentNode = head;
   while (currentNode != NULL)
   {
      if (currentNode->data == anEntry)
      {
         return true;
      }
      currentNode = currentNode->next;
      traverseCount++;
   }
   return false;
}

/** Get the count of number of nodes traversed.
    @return  The integer number of nodes traversed since last time the count was reset. */
int LinkedList :: getTraverseCount()
{
   return traverseCount;
}

/** Reset the count of nodes traversed to zero. */
void LinkedList :: resetTraverseCount()
{
   traverseCount = 0;
}
