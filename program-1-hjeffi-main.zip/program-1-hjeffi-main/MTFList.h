// MTF Linked List header file
// Created by Hannah Jeffi Leo Paul -Student No:2279688 [10/19/2022]
#pragma once
#include <iostream>
#include "LinkedList.h"

using namespace std;

class MTFList : public LinkedList
{
public:
    /** Constructor for MTFList
    @post Initialize the values of traverseCount to 0 and head Node to nullptr. */
    MTFList();

    /** Destructor for MTFList
    @post Deletes the Linked List by calling clear() method for clearing memory. */
    ~MTFList();

    /** Tests whether this list contains a given entry.
    @param anEntry  The entry to locate.
    @return  True if list contains anEntry, or false otherwise.
    @function called - moveToFront(Node *prevNode,int anEntry) to move the node to front */
    bool contains(int anEntry);

    /** Move the given entry to the front of the List.
    @param prevNode Pointer to the previous node to be moved.
    @param anEntry The entry to move
    @return  True if the entry has moved, or false otherwise. */
    bool moveToFront(Node *prevNode, int anEntry);
};