// Linked List header file
// Created by Hannah Jeffi Leo Paul -Student No:2279688 [10/19/2022]
# pragma once
#include <iostream>
#include "IList.h"

using namespace std;
struct Node
{
public:
    int data;
    Node *next;
    /** Constructor for Node
    Initialises the data to 0 and next to nullptr. */
    Node();

    /** Parameterized Constructor for the node
    @post Sets the value of the data to newEntry and next to nullptr
    @param newEntry The entry to be added in the new node. */
    Node(int newEntry);
};

class LinkedList
{
public:
    int traverseCount;
    Node *head;
    /** Constructor for LinkedList
    @post Initialize the values of traverseCount to 0 and head Node to nullptr. */
    LinkedList();

    /** Destructor for LinkedList
    @post Deletes the Linked List by calling clear() method for clearing memory. */
    ~LinkedList();

    /** Gets the current number of entries in this list.
    @return The integer number of entries currently in the list. */
    int getCurrentSize();

    /** Sees whether this list is empty.
    @return True if the list is empty, or false if not. */
    bool isEmpty();

   /** Adds a new entry to this list.
    @post  If successful, newEntry is stored in the list and
      the count of items in the list has increased by 1.
    @param newEntry  The object to be added as a new entry.
    @return  True if addition was successful, or false if not. */
    bool add(int newEntry);

    /** Removes one occurrence of a given entry from this list,
       if possible.
    @post  If successful, anEntry has been removed from the list
       and the count of items in the list has decreased by 1.
    @param anEntry  The entry to be removed.
    @return  True if removal was successful, or false if not. */
    bool remove(int anEntry);

    /** Removes all entries from this list.
    @post  List contains no items, and the count of items is 0. */
    void clear();
    
   /** Tests whether this list contains a given entry.
    @param anEntry  The entry to locate.
    @return  True if list contains anEntry, or false otherwise. */
    virtual bool contains(int anEntry);
   
    /** Get the count of number of nodes traversed.
    @return  The integer number of nodes traversed since last time the count was reset. */
    int getTraverseCount();
     
   /** Reset the count of nodes traversed to zero. */
    void resetTraverseCount();
    
};


